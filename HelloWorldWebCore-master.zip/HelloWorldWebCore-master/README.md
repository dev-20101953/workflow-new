# HelloWorldWebCore
A basic Hello World Asp.Net application for showcasing CI/CD scenarios